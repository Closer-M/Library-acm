#include <stdio.h>

int main()
{
	int m,x,a[100005];
	scanf("%d",&m);
	for(x=0;x<m;x++)
	{
    	int n;
    	scanf("%d",&n);
    	int i,j=0;
    	for(i=0;i<n;i++)
    	{
    		scanf("%d",&a[i]);
    		j += a[i];
		}
		printf("%d\n",j);
		if(x!=m-1)
		{
			printf("\n");
		} 
	}
    return 0;
}
