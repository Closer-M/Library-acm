#include <stdio.h>

int main()
{
	int n,a[100005];
    while(~scanf("%d",&n))
    {
		int i,j=0;
    	for(i=0;i<n;i++)
    	{
    		scanf("%d",&a[i]);
    		j += a[i];
		}
		printf("%d\n",j);
	}
	return 0;
}
