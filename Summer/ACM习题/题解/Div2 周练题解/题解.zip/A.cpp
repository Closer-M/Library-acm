#include<iostream>
using namespace std;
int m,n,ans,from,to;
int fa[1005];
void init(){
	for(int i=1;i<=n;i++)
		fa[i]=i;
	ans=0;
}
int fd(int x){
	return fa[x]==x?x:fa[x]=fd(fa[x]);
}
void unio(int x,int y){
 int fx=fd(x),fy=fd(y);
    if(fx!=fy) fa[fx]=fy;
}
int main(){
	while(cin>>n){
		if(n==0)
			break;
		cin>>m;
		init();
		for(int i=1;i<=m;i++){
			cin>>from>>to;
			unio(from,to);
		}
		int temp=fa[1];
		for(int i=2;i<=n;i++){
			if(fd(i)!=fd(temp)){
				unio(i,1);
				ans++;
			} 
		}
		cout<<ans<<endl;
	}
	return 0;
}
