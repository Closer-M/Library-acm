#include<iostream>
#include<stack>
using namespace std;
string s;
int l,r,ans,cnt;
int main(){
	cnt=1;
	while(cin>>s){
		l=r=ans=0;
		stack<char>st;
		if(s[0]=='-')
			break;
		int ll=s.size();
		for(int i=0;i<ll;i++){
			//cout<<s[i]<<endl;
			if(s[i]=='{'){
				l++;
				st.push(s[i]);
			}	
			else if(s[i]=='}'){
				r++;
				if(st.size()&&st.top()=='{'){
					st.pop();
					l--,r--;
				}
			}
		}
		cout<<cnt++<<'.'<<' '<<(l+1)/2+(r+1)/2<<endl;
	}
	return 0;
} 
