#include <iostream>
#include <string.h>
#include <cmath>
#include <cstring>
#include <cstdlib>
#include <algorithm>
using namespace std;
int main(){
    int t;
    cin>>t;
    for(int i=1;i<=t;i++){
        cout<<"Case "<<i<<':'<<endl;
        int a[1005]={0},b[1005]={0};
        string s,q;
        cin>>s>>q;
        cout<<s<<" + "<<q<<" = ";
        int f=s.size();
        int g=q.size();
        for(int j=0;j<f;j++){
            a[j]=s[f-1-j]-'0';
        }
        for(int k=0;k<g;k++){
            b[k]=q[g-1-k]-'0';
        }
        if(f>=g){
            for(int w=0;w<f;w++){
                if(a[w]+b[w]<10){
                    a[w]=a[w]+b[w];
                }
                else{
                    a[w]=a[w]+b[w]-10;
                    a[w+1]++;
                }
            }
            for(int w=f-1;w>=0;w--){
                cout<<a[w];
            }
        }
        else{
            for(int w=0;w<g;w++){
                if(a[w]+b[w]<10){
                    b[w]=a[w]+b[w];
                }
                else{
                    b[w]=a[w]+b[w]-10;
                    b[w+1]++;
                }
            }
            for(int w=g-1;w>=0;w--)
                cout<<b[w];
        }
        cout<<endl;
        if(i!=t)
            cout<<endl;
    }
    return 0;
}
