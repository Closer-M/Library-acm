//K  hdu1213 
//ģ����
#include<stdio.h>
const int MAX=1005;
int pre[MAX];
void init(int n){
	for(int i=1;i<=n;i++)
	pre[i]=i;
}
int find(int x){
	if(pre[x]==x) return x;
	return pre[x]=find(pre[x]);
}
void unite(int x,int y){
	x=find(x);
	y=find(y);
	if(x==y) return;
	pre[x]=y; 
}
int main(){
	int t,n,m,x,y;
	scanf("%d",&t);
	while(t--){
		int cnt=0;
		scanf("%d%d",&n,&m);
			init(n);
			while(m--){			
			scanf("%d%d",&x,&y);
			unite(x,y);			
		}
		for(int i=1;i<=n;i++)
			if(i==find(i))cnt++;
		printf("%d\n",cnt);
	}
	return 0;
}
