//I HDU2102
//BFS��ģ�� 
//Ҫ���������Թ���ͬλ��ͬʱΪ# �����ߵ����
#include <bits/stdc++.h>
#define FAST_IO ios::sync_with_stdio(false);cin.tie(NULL);cout.tie(NULL)
#define CaseT int T;cin >> T;for(int cas=1;cas<=T;cas++)
#define clr(a,b) memset(a,b,sizeof(a))
#define all(x) (x).begin(),(x).end()
#define pb push_back
#define fst first
#define sec second
using namespace std;
typedef long long ll;
typedef unsigned long long ull;
typedef long double ld;
typedef pair<int,int> pii;
typedef pair<ll,ll> pll;
const double EPS = 1e-8;
const double PI = acos(-1.0);
const int INF = 0x3f3f3f3f;
const int MOD = 1e9+7;
const int M = 2e5+20;
const int N = 15;

const int dx[4] = {0,0,1,-1}, dy[4] = {1,-1,0,0};

int n,m,t;
char mp[2][N][N];
int vis[2][N][N];
struct node{
    int z,x,y,step;
    node(){}
    node(int z,int x,int y,int step):z(z),x(x),y(y),step(step){}
}now,tmp;
queue<node>Q;

bool check(int z,int x,int y){
    if(x<0||x>=n||y<0||y>=m) return 0;
    if(vis[z][x][y]) return 0;
    if(mp[z][x][y]=='*') return 0;
    if(mp[z][x][y]=='#'&&mp[(1-z)][x][y]=='#') return 0;
    return 1;
}

int bfs(int z,int x,int y){
    Q.push(node(z,x,y,0));
    vis[z][x][y] = 1;
    while(Q.size()){
        now = Q.front();Q.pop();
        if(mp[now.z][now.x][now.y]=='P') return now.step;
        for(int i=0;i<4;i++){
            tmp.z = now.z;
            tmp.x = now.x + dx[i];
            tmp.y = now.y + dy[i];
            tmp.step = now.step + 1;
            if(mp[tmp.z][tmp.x][tmp.y]=='#') tmp.z ^= 1;
            if(check(tmp.z,tmp.x,tmp.y)){
//                cout << tmp.z << ' ' << tmp.x << ' ' << tmp.y << endl;
                vis[tmp.z][tmp.x][tmp.y] = 1;
                Q.push(tmp);
            }
        }
    }
    return INF;
}

void init(){
    clr(mp,0);
    clr(vis,0);
    while(Q.size()) Q.pop();
}

int main(){
    FAST_IO;
    CaseT{
        init();
        cin >> n >> m >> t;
        for(int i=0;i<2;i++){
            for(int j=0;j<n;j++){
                cin >> mp[i][j];
            }
        }
        int ans = bfs(0,0,0);
        cout << (ans<=t?"YES":"NO") << endl;
    }
    return 0;
}

