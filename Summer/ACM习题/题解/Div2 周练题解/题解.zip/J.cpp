//J
#include <iostream>
#include <cstdio>
#include <cstring>
const int MAXN = 50004;
int a[MAXN];
char s[20];

using namespace std;

int lowbit(int x)
{
	return x & (-x);	
}

void update(int x, int var, int n)
{
	while (x <= n)
	{
		a[x] += var;
		x += lowbit(x);
	}
}

int sum(int x, int n)
{
	int sum = 0;
	while (x > 0)
	{
		sum += a[x];
		x -= lowbit(x);
	}
	
	return sum;
}

int main(void)
{
	int i, j, T, n;
	cin >> T;
	
	for (i = 1; i <= T; i++)
	{
		cin >> n;
		memset(a, 0, sizeof(a));
		int t;
		for (j = 1; j <= n; j++)
		{
			cin >> t;
			update(j, t, n);
		}
		int x, y;
		
		printf("Case %d:\n", i);
		while (scanf("%s", s) != EOF && strcmp(s, "End") != 0)
		{
			cin >> x >> y;
			if (strcmp(s, "Add") == 0)
			{
				update(x, y, n);
			} 
			else if (strcmp(s, "Sub") == 0)
			{
				update(x, -y, n);
			}
			else 
			{
				printf("%d\n", sum(y, n) - sum(x - 1, n));
			}
		}
	}
	
	return 0;	
}
