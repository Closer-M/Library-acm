//H 
#include <iostream>
#include <cstdio>
#include <cmath>
#include <cstring>

using namespace std;

int main(void)
{
	int n;
	double ans = 0x3f3f, time = 0;
	
	while (cin >> n && n)
	{
		ans = 0x3f3f;
		int t, v;
		while (n--)
		{
			cin >> v >> t;
			if (t >= 0)
			{
				time = t + 4.5 / v * 3600;
				if (time < ans)
					ans = time;
			}
		}
		if ((int)ans != ans)
			ans = int(ans) + 1;
		cout << ans << endl;
	}
	
	return 0;	
}
