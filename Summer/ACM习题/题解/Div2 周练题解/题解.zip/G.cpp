#include<iostream>
#include<string.h>
#include<map>
#include<math.h> 
#include<algorithm>
using namespace std;
int n,m,k,a,b,c;
int w[15][105],p[15][105],dp[15][100005]; 
map<int,int>mp;
int main(){
	while(cin>>n>>m>>k){
		memset(w,0,sizeof(w));
		memset(p,0,sizeof(p));
		memset(dp,-1,sizeof(dp));
		mp.clear();
		mp[0]=1;
		for(int i=0;i<=k;i++){
			for(int j=0;j<=m;j++){
		     	dp[i][j] = i==0?0:-1;
	        }
	    }
		for(int i=1;i<=n;i++){
			cin>>a>>b>>c;
			mp[a]++;
			w[a][mp[a]]=b;
			p[a][mp[a]]=c;
		}
		for(int i=1;i<=k;i++){
			for(int j=1;j<=mp[i];j++){
				for(int u=m;u>=w[i][j];u--){
					if(dp[i][u-w[i][j]]!=-1){
						dp[i][u]=max(dp[i][u],dp[i][u-w[i][j]]+p[i][j]);
					} 
					if(dp[i-1][u-w[i][j]]!=-1){
						dp[i][u]=max(dp[i][u],dp[i-1][u-w[i][j]]+p[i][j]);
					}
				}
			}
		}
		if(dp[k][m]<0) cout<<"Impossible"<<endl;
		else
			cout<<dp[k][m]<<endl;
	}
	return 0;
}
