#include"iostream"
using namespace std;
int n;
int a[200],b[200],time;
bool equal(){
	bool result=true;
	for (int i=1;i<n;i++) {
		if (a[i]!=a[0]) {
			result=false;
			break;
		}
	}
	return result;
}
int main(){
	while(cin>>n&&n){
		time=0;
		for(int i=0;i<n;i++){
			cin>>a[i];
		}
		while (!equal()){
			a[0]/=2;
			b[0]=a[0];
			for(int i = 1;i<n;i++) {
				a[i]/=2;
				b[i]=a[i];
				a[i]=a[i]+b[i-1];
			}
			a[0]=a[0]+b[n-1];
			for(int i=0;i<n;i++){
				if(a[i]%2==1) 
					a[i]+=1;
			}
			time++;
		}
		cout<<time<<" "<<a[0]<<endl;
	}
	return 0;
}
