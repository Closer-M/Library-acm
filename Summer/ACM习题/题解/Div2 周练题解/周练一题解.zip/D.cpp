#include<iostream>
#include<string.h>
using namespace std;
int main(){
	int n,k;
	cin>>n>>k;
	while(k--){
		int temp=n%10;
		if(temp==0)
			n/=10;
		else
			n--; 
	}
	cout<<n<<endl;
    return 0;
}      
