#include <iostream>
#include <algorithm>
#include <string.h>
using namespace std;

int main(){
    int l,t,w,y=0;
    cin>>t; 
    getchar();//����س��� 
    string s;
      while(t--){//ѭ��t�� 
        int a=0,e=0,i=0,o=0,u=0;
        getline(cin,s);//���ո�Ҳ��Ϊһ���ַ����� 
        w=s.size();//����ַ����ĳ��� 
        for(int j=0;j<w;j++){
            if(s[j]=='a')
                a++;
            else if(s[j]=='e')
                e++;
              else if(s[j]=='i')
                i++;
            else if(s[j]=='o')
                o++;
            else if(s[j]=='u')
                u++;
         }
         
        cout<<"a"<<':'<<a<<endl;
        cout<<"e"<<':'<<e<<endl;
        cout<<"i"<<':'<<i<<endl;
        cout<<"o"<<':'<<o<<endl;
        cout<<"u"<<':'<<u<<endl;//���
         
        if(t!=0)
          cout<<endl;
    }
