#include<iostream>
#include<math.h>
#include<string.h>
using namespace std;
int main(){
    int n,t,flag;
    cin>>t;
    for(int i=1;i<=t;i++){
    	flag=1;
		cin>>n;
    	for(int j=2;j*j<=n;j++){
    		if(n%j==0){
    			cout<<"No"<<endl;
    			flag=0;
				break;
			}
		}
		if(flag)
			cout<<"Yes"<<endl;
	}
    return 0;
}
