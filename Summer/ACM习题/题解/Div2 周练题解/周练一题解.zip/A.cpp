#include <iostream>
#include <stdio.h>
using namespace std;
int a[105];

int main()
{
    int n;
    while(cin>>n)
    {
        int ma=0,mi=1000;
        for(int i=1;i<=n;i++)
        {
            cin>>a[i];
            if(ma<a[i])
                ma=a[i];
            if(mi>a[i])
                mi=a[i];
        }
        double sum=0;
        for(int i=1;i<=n;i++)
        {
            if(a[i]!=ma&&a[i]!=mi)
                sum+=a[i];
        }
        sum=sum/(n-2.0);
        printf("%.2lf\n",sum);
    }
    return 0;
}
