#include<iostream>
#include<string.h>
using namespace std;
int main(){
   	int x,a,b,c,d;
   	cin>>x;
   	for(int i=x+1;i<=9999;i++){
   		a=i/1000;
		b=(i-a*1000)/100;
		c=(i-a*1000-b*100)/10;
		d=i%10;
		if(a!=b&&a!=c&&a!=d&&b!=c&&b!=d&&c!=d){
			cout<<i<<endl;
			break;
		}
	}
    return 0;
}      
