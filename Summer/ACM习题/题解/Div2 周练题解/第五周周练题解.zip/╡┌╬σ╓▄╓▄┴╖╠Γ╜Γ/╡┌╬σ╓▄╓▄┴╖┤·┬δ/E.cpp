#include<stdio.h>
#include<string.h>
int main()
{ 
	int N, i , j, a = 0, b = 0, flag = 0;
	char s[1002][16]; 
	while(scanf("%d", &N) != EOF) 
	{ 
		if (N == 0)  break;
		flag = 0; 
		for(i = 0; i < N; i++) 
			scanf("%s", s[i]);
		for(i = 0; i < N; i++) 
		{
			a = 0; 
			for(j = 0; j < N; j++) 
				if(strcmp(s[i],s[j])==0) 
					a++;
			if(a > b) 
			{ 
				b = a; 
				flag = i; 
			}
		} 
		printf("%s\n", s[flag]); 
	} 
	return 0;
} 

