#include<iostream>
#include<algorithm>
#include<cstring>
#include<cstdio>
using namespace std;
 
char s[220],ch;
 
int main()
{
    while(cin >> ch >> s)
    {
        int len = strlen(s);
        int num = 0;
        if(isupper(ch))
            ch += 32;
        for(int i = 0; i < len; ++i)
        {
            if(isupper(s[i]))
                s[i] += 32;
            if(ch == s[i])
                num++;
        }
 
        printf("%0.5lf\n",num*1.0/len);
    }
 
    return 0;
}

