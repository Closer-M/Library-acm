/* HDU2040 �׺��� */
 
#include <iostream>
#include <cstring>
 
using namespace std;
 
const int MAXN = 600000;
 
int sum[MAXN+1];
 
void maketable(int n)
{
    memset(sum, 0, sizeof(sum));
    sum[1] = 0;
 
    int i=2, j;
    while(i<=n) {
        sum[i]++;
        j = i + i;      /* j=ki, k>1 */
        while(j <= n) {
            sum[j] += i;
            j += i;
        }
        i++;
    }
}
 
int main()
{
    int m, a, b;
 
    maketable(MAXN);
 
    cin >> m;
    while(m--) {
        cin >> a >> b;
 
        if(b == sum[a] && a == sum[b])
            cout << "YES" << endl;
        else
            cout << "NO" << endl;
    }
 
    return 0;
}

