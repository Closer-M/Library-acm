#include<cstdio>
int a[25];
void Init()
{
    int m = 1;//2^n
    for(int i = 1;i <= 20;i++)
    {
        a[i] = m + m/2*(i-1);
        m *= 2;
    }
}
int main()
{
    Init();
    int t,n;
    scanf("%d",&t);
    while(t--)
    {
        scanf("%d",&n);
        printf("%d\n",a[n]);
    }
    return 0;
}

