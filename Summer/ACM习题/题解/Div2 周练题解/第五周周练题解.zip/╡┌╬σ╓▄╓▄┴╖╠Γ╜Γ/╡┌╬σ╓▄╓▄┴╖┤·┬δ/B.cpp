/* HDU2041 ����¥�� */
 
#include <stdio.h>
 
#define MAXN 40
 
typedef long long LL;
 
LL fn[MAXN+1];
 
void setfn()
{
    int i;
 
    fn[1] = 0;
    fn[2] = 1;
    fn[3] = 2;
    for(i=4; i<=MAXN; i++)
        fn[i] = fn[i-2] + fn[i-1];
}
 
int main()
{
    int n, m;
 
    // �ȴ��
    setfn();
 
    scanf("%d", &n);
    while(n--) {
        scanf("%d", &m);
        printf("%lld\n", fn[m]);
    }
 
    return 0;
}

