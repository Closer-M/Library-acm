#include <iostream>
#include <stdio.h>
#include <string.h>
#include <algorithm>
#include <queue>
#include <math.h>
#define ll long long
using namespace std;
char a[100];
int main()
{
    while(scanf("%s",a)&&a[0]!='#')
    {
        if(a[0]=='#')
            break;
        int sum=0;
        int len=strlen(a);
        for(int i=0;i<len-1;i++)
        {
            sum+=a[i]-'0';
            printf("%c",a[i]);
        }
        if((sum%2==0&&a[len-1]=='e')||(sum%2==1&&a[len-1]=='o'))
        {
            printf("0\n");
        }
        else
        {
            printf("1\n");
        }
    }
    return 0;
}

