#include<iostream>
#include<cstdio>
#include<map>
 
using namespace std;
 
long long  f[60]={0,1,2,3};
map<int,long long >cow;
 
int main()
{
    cow[1]=1;
    cow[2]=2;
    cow[3]=3;
    for(int i=4;i<60;i++)
    {
        f[i]=f[i-3]+f[i-1];
        cow[i]=f[i];
    }
    int n;
    while(scanf("%d",&n)&&n)
    {
        cout<<cow[n]<<endl;
    }
    return  0;
}

