#include <stdio.h>
#include <math.h>
 
int main()
{
	double a,b,c,d;
	int n;
	
	scanf("%d",&n);
	while(n--)
	{
		scanf("%lf%lf%lf%lf",&a,&b,&c,&d);
		printf("%.1f\n",sqrt((a-c)*(a-c)+(b-d)*(b-d)));
	}
	
	return 0;
 } 

