#include <iostream>
#include <stdio.h>
using namespace std;
int num[5005];
int vis[20001]={0};
int j=0;
void Prime()
{
    for (int i=2;i<20001;i++)
    {
        if (vis[i])
            continue;
        for (int k=2;k*i<20001;k++)
            vis[k*i]=1;
    }
}
int main()
{
    int n;
    Prime();
    while (~scanf("%d",&n))
    {
        int maxx=0,num=1;
        for (int i=0;i<n;i++)
        {
            int flag=1;
            int a;
            cin>>a;
            for (int k=1;k<a;k++)
            {
                if (a%k==0&&!vis[a/k])
                {
                    flag=a/k;
                    break;
                }
            }
            if (maxx<flag)
            {
                maxx=flag;
                num=a;
            }
        }
        cout<<num<<endl;
    }
    return 0;
}

