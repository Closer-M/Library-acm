#include <iostream>
#include <algorithm>
using namespace std;
const int N = 105;

struct node{
	int from, to;
};

int n;
node a[N];

bool cmp(node a, node b){
	return a.to<b.to;
}

int main(){
	while(cin >> n && n){
		for(int i=1;i<=n;i++){
			cin >> a[i].from >> a[i].to;
		}
		sort(a+1, a+n+1, cmp);
		int ans = 1;
		for(int i=1;i<=n;i++){
			for(int j=i+1;j<=n;j++){
				if(a[j].from >= a[i].to){
					ans++;
					i = j;
				}
			}
		}
		cout << ans << endl;
	}
	return 0;
}
