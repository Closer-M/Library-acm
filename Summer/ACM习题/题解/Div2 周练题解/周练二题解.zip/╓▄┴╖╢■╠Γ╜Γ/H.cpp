#include <iostream>
#include <queue>
#include <algorithm>
using namespace std;

const int N = 1005;

// solution 1
int n;
int a[N];

int main(){
	while(cin >> n){
		for(int i=1;i<=n;i++) cin >> a[i];
		int ans = 0;
		for(int i=1;i<n;i++){
			sort(a+1, a+n+1);
			ans += (a[1] + a[2]);
			a[1] += a[2];
			a[2] = 1000000000;
		}
		cout << ans << endl;
	}
	return 0;
}

// solution 2
int n, x;
priority_queue<int, vector<int>, greater<int> >pq;

int main(){
	while(cin >> n){
		for(int i=1;i<=n;i++){
			cin >> x;
			pq.push(x);
		}
		int ans = 0;
		for(int i=1;i<n;i++){
			int l1 = pq.top(); pq.pop();
			int l2 = pq.top(); pq.pop();
			ans += (l1 + l2);
			pq.push(l1+l2);
		}
		cout << ans << endl;
	}
	return 0;
}
