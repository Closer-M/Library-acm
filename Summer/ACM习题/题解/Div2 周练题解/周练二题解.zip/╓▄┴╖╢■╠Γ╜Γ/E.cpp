#include <iostream>
using namespace std;
const int N = 1e4+20;

struct preson{
	string who;
	string from, to;
};

int n;
preson arr[N];
preson open, close;

int main(){
	int T;
	cin >> T;
	while(T--){
		cin >> n;
		for(int i=1;i<=n;i++){
			cin >> arr[i].who >> arr[i].from >> arr[i].to;
		}
		
		open = close = arr[1];
		
		for(int i=2;i<=n;i++){
			if(arr[i].from < open.from) open  = arr[i];
			if(arr[i].to   > close.to)  close = arr[i];
		}
		
		cout << open.who << ' ' << close.who << endl;
	}
	return 0;
}
