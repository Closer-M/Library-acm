#include <iostream>
#include <algorithm>
using namespace std;

const int N = 105;

int n, arr[N];

bool cmp(int a, int b){
	return abs(a) > abs(b);
}

int main(){
	while(cin >> n && n){
		for(int i=1;i<=n;i++) cin >> arr[i];
		
		sort(arr+1, arr+n+1, cmp);
		
		for(int i=1;i<=n;i++) cout << arr[i] << " \n"[i==n];
	}
	return 0;
}
