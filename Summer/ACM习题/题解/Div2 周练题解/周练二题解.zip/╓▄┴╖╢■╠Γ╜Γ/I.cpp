#include <iostream>
using namespace std;

const int N = 1e5+5;

int n;
long long ans[N];

long long cal(int x){
	int dit[10], siz = 0;
	long long res = x;
	
	while(x){
		dit[siz++] = x%10;
		x/=10;
	}
	
	for(int i=1;i<siz;i++){
		res = res*10 + dit[i];
	}
	
	return res;
}

int main(){
	for(int i=1;i<=100000;i++) ans[i] = cal(i);
	
	while(cin >> n){
		for(int i=1;i<=n;i++) cout << ans[i] << " \n"[i==n];
	}
	
	return 0;
}
