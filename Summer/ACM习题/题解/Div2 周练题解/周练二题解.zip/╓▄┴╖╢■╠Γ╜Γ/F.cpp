#include <iostream>
#include <algorithm>
using namespace std;

const int N = 1e6+5;

int n, m;
int arr[N];

bool cmp(int a, int b){
	return a > b;
}

int main(){
	while(~scanf("%d %d", &n, &m)){
		for(int i=1;i<=n;i++) scanf("%d", arr+i);
		
		sort(arr+1, arr+n+1, cmp);
		
		for(int i=1;i<=m;i++) printf("%d%c", arr[i], " \n"[i==m]);
	}
	return 0;
}
