#include <iostream>
#include <cstring> 
using namespace std;

const int N = 100+20;

int a,b,c;
char g[N][N];

int main(){
    int T;
	cin >> T;
	while(T--){
		memset(g, 0, sizeof g);
        cin >> a >> b >> c;
        int n = (b+c)*2+1;
        int m = (a+b)*2+1;    
        for(int i=1;i<=n;i++){
            for(int j=1;j<=m;j++){
                g[i][j] = '.';
            } 
        }
        for(int i=b*2+1;i<=n;i+=2){
            for(int j=1;j<=a*2+1;j+=2){
                g[i][j] = '+';
                g[i+1][j] = '|';
                g[i][j-1] = '-';
            }
        }
        int cnt;
        for(int i=2*b;i>=1;i--){
            cnt = 0;
            for(int j=1;j<=m;j++){
                if(g[i+1][j-1]=='+') g[i][j] = '/';
                else if(g[i+1][j-1]=='/') g[i][j] = '+';
                else if(g[i][j-1]=='+') g[i][j] = '-',cnt++;
                if(cnt==a) break;
            }
        }
        for(int i=n;i>=1;i--){
            for(int j=2*a+2;j<=m;j++){
                if(g[i+1][j-1]=='+') g[i][j] = '/';
                else if(g[i+1][j-1]=='/') g[i][j] = '+';
            }
        }
        for(int j=m;j>2*a+2;j-=2){
            for(int i=m-j+1;i<=n;i++){
                if(g[i+1][j]=='+') g[i][j] = '|'; 
            }
        }
        for(int i=1;i<=n;i++){
            for(int j=1;j<=m;j++){
                cout << g[i][j];
            }
            cout << endl;
        }
    }
    return 0;
}
