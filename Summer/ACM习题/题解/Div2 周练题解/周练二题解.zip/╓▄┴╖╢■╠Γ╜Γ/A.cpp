#include <iostream>
using namespace std;

int num;

int main(){
	int T;
	cin >> T;
	while(T--){
		cin >> num;
		
		int cnt = 0;
		
		while(num>1){
			if(num%2==1){
				if(cnt>0) cout << ' ';
				cnt++;
				cout << num;
				num = num*3 + 1;
			}
			else{
				num/=2;
			}
		}
		
		if(cnt == 0) cout << "No number can be output !";
		
		cout << endl;
	}
	return 0;
}
