#include <iostream>
#include <algorithm>
#include <cstring>
#include <string>
using namespace std;

const int N = 60;

// solution 1
char str[N];

int pal(const char* s){
	int n = strlen(s);
	for(int i=0, j=n-1; i<j; i++, j--){
		if(s[i]!=s[j]) return 0;
	}
	return 1;
}

int main(){
	int cas = 0;
	while(~scanf("%s",str)){
		if(strcmp(str, "STOP") == 0) break;
		
		printf("#%d: ", ++cas);
	
		if(pal(str)) puts("YES");
		else puts("NO");
	}
	return 0;
}

// solution 2
string str;	/*string is a type in C++*/

int main(){
	int cas = 0;
	while(cin >> str){
		if(str == "STOP") break;
		
		printf("#%d: ", ++cas);
		
		string tmp = str;
		reverse(tmp.begin(), tmp.end());

		if(str == tmp) puts("YES");
		else puts("NO");
	}
	
}
